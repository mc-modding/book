package ru.mousecray.plants.items;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraft.client.Minecraft;
import net.minecraft.item.Item;

public class ListItems {
	
	public static Item CAVE_SEEDS = new CaveSeeds();
	
	public static void onRegister() {
		register(CAVE_SEEDS);
	}
	
	@SideOnly(Side.CLIENT)
	public static void onRender() {
		registerRender(CAVE_SEEDS);
	}

    private static void register(Item item) {
	    //������������� �������
	    ForgeRegistries.ITEMS.register(item);
	}

	@SideOnly(Side.CLIENT)
	private static void registerRender(Item item) {
		//������������ ������ ��������
		Minecraft.getMinecraft().getRenderItem().getItemModelMesher().register(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
	}
}